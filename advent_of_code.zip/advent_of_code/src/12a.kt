import java.io.File

fun calculateFencingCost(map: List<String>): Int {
    val rows = map.size
    val cols = map[0].length
    val visited = Array(rows) { BooleanArray(cols) }
    var totalCost = 0

    val directions = listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))

    fun isValid(x: Int, y: Int) = x in 0 until rows && y in 0 until cols

    fun floodFill(x: Int, y: Int, plant: Char): Pair<Int, Int> {
        var area = 0
        var perimeter = 0
        val queue = ArrayDeque<Pair<Int, Int>>()
        queue.add(Pair(x, y))
        visited[x][y] = true

        while (queue.isNotEmpty()) {
            val (cx, cy) = queue.removeFirst()
            area++

            for ((dx, dy) in directions) {
                val nx = cx + dx
                val ny = cy + dy

                if (!isValid(nx, ny) || map[nx][ny] != plant) {
                    perimeter++
                } else if (!visited[nx][ny]) {
                    visited[nx][ny] = true
                    queue.add(Pair(nx, ny))
                }
            }
        }

        return Pair(area, perimeter)
    }

    for (x in 0 until rows) {
        for (y in 0 until cols) {
            if (!visited[x][y]) {
                val plant = map[x][y]
                val (area, perimeter) = floodFill(x, y, plant)
                totalCost += area * perimeter
            }
        }
    }

    return totalCost
}

fun main() {
    val filePath = "12b.txt"
    val map = File(filePath).readLines()

    val totalCost = calculateFencingCost(map)
    println(totalCost)
}
