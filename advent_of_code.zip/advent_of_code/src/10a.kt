import java.io.File

fun findUniqueTrailLengths(map: List<String>): Int {
    val numRows = map.size
    val numCols = map[0].length
    val directions = listOf(Pair(0, 1), Pair(1, 0), Pair(0, -1), Pair(-1, 0))

    fun isValid(x: Int, y: Int): Boolean {
        return x in 0 until numRows && y in 0 until numCols && map[x][y] != '.'
    }

    fun dfs(x: Int, y: Int, height: Int, visited: MutableSet<Pair<Int, Int>>): Set<Pair<Int, Int>> {
        val trailPeaks = mutableSetOf<Pair<Int, Int>>()

        fun dfsRecursive(cx: Int, cy: Int, currentHeight: Int) {
            if (!isValid(cx, cy) || map[cx][cy].digitToInt() != currentHeight || Pair(cx, cy) in visited) return
            visited.add(Pair(cx, cy))

            if (currentHeight == 9) {
                trailPeaks.add(Pair(cx, cy))
                return
            }

            val nextHeight = currentHeight + 1
            for ((dx, dy) in directions) {
                val nx = cx + dx
                val ny = cy + dy
                dfsRecursive(nx, ny, nextHeight)
            }
        }

        dfsRecursive(x, y, height)
        return trailPeaks
    }

    var visited = mutableSetOf<Pair<Int, Int>>()
    var totalTrailLength = 0

    for (x in 0 until numRows) {
        for (y in 0 until numCols) {
            if (map[x][y] == '0' && Pair(x, y) !in visited) {
                visited = mutableSetOf<Pair<Int, Int>>()
                val trailPeaks = dfs(x, y, 0, visited)
                totalTrailLength += trailPeaks.size
            }
        }
    }

    return totalTrailLength
}

fun main() {
    val fileName = "10b.txt"
    val map = File(fileName).readLines()

    val totalLength = findUniqueTrailLengths(map)
    println(totalLength)
}
