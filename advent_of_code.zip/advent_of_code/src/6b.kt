import java.io.File

fun main() {
    val input = File("6b.txt").readText()

    val lines = input.split("\n")
    val grid = Array(lines.size) { CharArray(lines[0].length) }

    var currentPosition = Pair(0,0)

    for (i in lines.indices) {
        for (j in lines[i].indices) {
            if (lines[i][j] == '^'){
                currentPosition = Pair(i, j)
                grid[i][j] = '|'
            } else {
                grid[i][j] = lines[i][j]
            }
        }
    }

    var options = 0;

    for (i in grid.indices) {
        for (j in grid[0].indices) {
            if (grid[i][j] == '.'){
                grid[i][j] = '#'
                if (loop(grid, currentPosition)) {
                    options++
                }
                grid[i][j] = '.'
            }

        }
    }
    print(options)
}

fun loop(grid_: Array<CharArray>, currentPosition_: Pair<Int,Int>): Boolean {
    val grid = grid_.map { it.copyOf() }.toTypedArray()
    var direction = Pair(-1, 0)
    var currentPosition = currentPosition_
    val visited = mutableSetOf<Triple<Int, Int, Pair<Int, Int>>>()
    while (currentPosition.first+direction.first >= 0 &&
        currentPosition.first+direction.first < grid.size &&
        currentPosition.second+direction.second >= 0 &&
        currentPosition.second+direction.second < grid[0].size){

        if (!visited.add(Triple(currentPosition.first, currentPosition.second, direction))) {
            return true
        }

        if (grid[currentPosition.first+direction.first][currentPosition.second+direction.second] == '#'){
            if (direction == Pair(-1, 0)){ //hore
                direction = Pair(0,1)
            } else if (direction == Pair(1, 0)){ //dole
                direction = Pair(0,-1)
            } else if (direction == Pair(0, -1)){ //vpravo
                direction = Pair(-1, 0)
            } else { //vpravo
                direction = Pair(1, 0)
            }
            grid[currentPosition.first][currentPosition.second] = '+'
        } else if (grid[currentPosition.first+direction.first][currentPosition.second+direction.second] == '|'){
            currentPosition = Pair(currentPosition.first + direction.first,currentPosition.second + direction.second)
            grid[currentPosition.first][currentPosition.second] = '+'
        } else if (grid[currentPosition.first+direction.first][currentPosition.second+direction.second] == '-'){
            currentPosition = Pair(currentPosition.first + direction.first,currentPosition.second + direction.second)
            grid[currentPosition.first][currentPosition.second] = '+'
        } else if (grid[currentPosition.first+direction.first][currentPosition.second+direction.second] == '+'){
            currentPosition = Pair(currentPosition.first + direction.first,currentPosition.second + direction.second)
        } else {
            currentPosition = Pair(currentPosition.first + direction.first,currentPosition.second + direction.second)
            if (direction.first == 0){
                grid[currentPosition.first][currentPosition.second] = '-'
            } else {
                grid[currentPosition.first][currentPosition.second] = '|'
            }
        }
    }
    /*for (row in grid) {
        println(row.joinToString(""))
    }
    println()*/
    return false
}
