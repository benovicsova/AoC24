import java.io.File

fun main() {
    val filePath = "5b.txt"
    val input = File(filePath).readText()

    val parts = input.split(Regex("\\n\\s*\\n")).map { it.trim() }

    val rulesSection = parts[0]
    val updatesSection = parts[1]

    val rules = rulesSection.lines().map { it.split('|').let { (x, y) -> x.toInt() to y.toInt() } }
    val updates = updatesSection.lines().map { it.split(',').map(String::toInt) }

    fun isUpdateValid(update: List<Int>): Boolean {
        val positionMap = mutableMapOf<Int, Int>()
        for (i in update.indices) {
            positionMap[update[i]] = i
        }

        for ((x, y) in rules) {
            if (positionMap.containsKey(x) && positionMap.containsKey(y)) {
                if (positionMap[x]!! >= positionMap[y]!!) {
                    return false
                }
            }
        }
        return true
    }

    var sum = 0;
    for (update in updates) {
        if (isUpdateValid(update)) {
            sum+= update[update.size/2]
        }
    }

    println(sum)
}
