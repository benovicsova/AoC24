import java.io.File

fun main() {
    val filePath = "3b.txt"
    val input = File(filePath).readText()

    var counts = true

    val mulRegex = "mul\\((\\d{1,3}),\\s*(\\d{1,3})\\)".toRegex()
    val doRegex = "do\\(\\)".toRegex()
    val dontRegex = "don't\\(\\)".toRegex()
    var sum = 0

    val segments = input.split(')').map { it.trim() + ")" }

    for (segment in segments) {

        val trimmedSegment = segment.trim()

        when {
            doRegex.containsMatchIn(trimmedSegment) -> counts = true
            dontRegex.containsMatchIn(trimmedSegment) -> counts = false
            mulRegex.containsMatchIn(trimmedSegment) -> {
                if (counts) {
                    val match = mulRegex.find(trimmedSegment)
                    val x = match?.groupValues?.get(1)?.toInt() ?: 0
                    val y = match?.groupValues?.get(2)?.toInt() ?: 0
                    sum += x * y
                }
            }
        }
    }

    println(sum)
}
