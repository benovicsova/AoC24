import java.io.File

data class Robot(val p_x: Int, val p_y: Int, val v_x: Int, val v_y: Int)

fun main() {
    val file = File("14b.txt")
    val robots = mutableListOf<Robot>()

    file.forEachLine { line ->
        val regex = """p=(-?\d+),(-?\d+) v=(-?\d+),(-?\d+)""".toRegex()
        val matchResult = regex.matchEntire(line.trim())
        matchResult?.let {
            val (p_x, p_y, v_x, v_y) = it.destructured
            robots.add(Robot(p_x.toInt(), p_y.toInt(), v_x.toInt(), v_y.toInt()))
        }
    }


    val width = 101
    val height = 103

    val updatedRobots = robots.map { robot ->
        var newX = (robot.p_x + (robot.v_x * 6587)) % width
        if (newX<0){
            newX+=width
        }
        var newY = (robot.p_y + (robot.v_y * 6587)) % height
        if (newY<0){
            newY+=height
        }
        //println("$newX, $newY")
        Robot(newX, newY, robot.v_x, robot.v_y)
    }

    drawMap(updatedRobots, width, height)



    println(countRobotsInQuadrants(updatedRobots, width, height))
}

fun drawMap(robots: List<Robot>, width: Int, height: Int) {
    val map = Array(height) { CharArray(width) { '.' } }

    for (robot in robots) {
        val x = robot.p_x
        val y = robot.p_y
        if (map[y][x] == '.') {
            map[y][x] = '1'
        } else if (map[y][x] in '1'..'9') {
            map[y][x] = (map[y][x] + 1)
        }
    }

    // Vypíšeme mapu
    for (row in map) {
        println(row.concatToString())
    }
}


fun countRobotsInQuadrants(robots: List<Robot>, width: Int, height: Int): Int {
    var topLeft = 0
    var topRight = 0
    var bottomLeft = 0
    var bottomRight = 0

    val middleX = width / 2
    val middleY = height / 2


    for (robot in robots) {
        if (robot.p_x == middleX || robot.p_y == middleY) continue

        when {
            robot.p_x < middleX && robot.p_y < middleY -> topLeft++
            robot.p_x > middleX && robot.p_y < middleY -> topRight++
            robot.p_x < middleX && robot.p_y > middleY -> bottomLeft++
            robot.p_x > middleX && robot.p_y > middleY -> bottomRight++
        }
    }

    return topLeft * topRight * bottomLeft * bottomRight
}

