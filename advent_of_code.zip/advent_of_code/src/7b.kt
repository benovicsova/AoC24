import java.io.File

fun main() {
    val input = File("7b.txt").readLines()

    var count = 0L
    for (line in input) {
        val (testValue, numbers) = parseInput2(line)
        if (canMatchTestValue2(testValue, numbers)) {
            count += testValue
        }
    }

    println(count)
}

fun parseInput2(line: String): Pair<Long, List<Long>> {
    val parts = line.split(": ")
    val testValue = parts[0].toLong()
    val numbers = parts[1].split(" ").map { it.toLong() }
    return Pair(testValue, numbers)
}

fun canMatchTestValue2(testValue: Long, numbers: List<Long>): Boolean {
    return evaluateCombinations2(numbers, testValue, 0, listOf(numbers[0]))
}

fun evaluateCombinations2(numbers: List<Long>, testValue: Long, index: Int, results: List<Long>): Boolean {
    if (index == numbers.lastIndex) {
        return results.any { it == testValue }
    }

    val nextIndex = index + 1
    val nextNumber = numbers[nextIndex]
    val newResults = mutableListOf<Long>()

    for (result in results) {
        newResults.add(result + nextNumber)
        newResults.add(result * nextNumber)
        newResults.add(concatenate(result, nextNumber)) 
    }

    return evaluateCombinations2(numbers, testValue, nextIndex, newResults)
}

fun concatenate(a: Long, b: Long): Long {
    return "$a$b".toLong()
}
