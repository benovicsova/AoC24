import java.io.File
import java.util.PriorityQueue

data class State2(val x: Int, val y: Int, val direction: Int, val score: Int, val path: Set<Pair<Int, Int>>) : Comparable<State2> {
    override fun compareTo(other: State2): Int = this.score - other.score
}

private fun <E : Comparable<E>> PriorityQueue<E>.addElement(element: E) {
    this.add(element)
}

fun main() {
    val map = File("16c.txt").readLines().map { it.toCharArray() }

    val start = map.indices.flatMap { y -> map[0].indices.map { x -> Pair(x, y) } }
        .first { map[it.second][it.first] == 'S' }
    val end = map.indices.flatMap { y -> map[0].indices.map { x -> Pair(x, y) } }
        .first { map[it.second][it.first] == 'E' }

    val bestPathCells = search2(start, end, map)

    println(bestPathCells)

}

private fun search2(
    start: Pair<Int, Int>,
    end: Pair<Int, Int>,
    map: List<CharArray>
): Int {
    val directions = listOf(Pair(1, 0), Pair(0, 1), Pair(-1, 0), Pair(0, -1))
    val queue = PriorityQueue<State2>()
    val visited = mutableMapOf<Triple<Int, Int, Int>, Int>()
    var shortestScore = Int.MAX_VALUE
    val bestPathCells = mutableSetOf<Pair<Int, Int>>()

    queue.addElement(State2(start.first, start.second, 0, 0, setOf(start)))

    while (queue.isNotEmpty()) {
        val current = queue.poll()

        val visitKey = Triple(current.x, current.y, current.direction)
        if (visitKey in visited && visited[visitKey]!! < current.score) continue
        visited[visitKey] = current.score

        if (current.x == end.first && current.y == end.second) {
            if (current.score < shortestScore) {
                shortestScore = current.score
                bestPathCells.clear()
            }
            if (current.score == shortestScore) {
                bestPathCells.addAll(current.path)
            }
            continue
        }

        val nextX = current.x + directions[current.direction].first
        val nextY = current.y + directions[current.direction].second
        if (nextX in map[0].indices && nextY in map.indices && map[nextY][nextX] != '#') {
            queue.addElement(State2(nextX, nextY, current.direction, current.score + 1, current.path + Pair(nextX, nextY)))
        }

        val rightDirection = (current.direction + 1) % 4
        queue.addElement(State2(current.x, current.y, rightDirection, current.score + 1000, current.path))

        val leftDirection = (current.direction + 3) % 4
        queue.addElement(State2(current.x, current.y, leftDirection, current.score + 1000, current.path))
    }
    return bestPathCells.size
}
