import java.io.File

fun calculateTrailheadScores(map: List<String>): Int {
    val numRows = map.size
    val numCols = map[0].length
    val directions = listOf(Pair(0, 1), Pair(1, 0), Pair(0, -1), Pair(-1, 0))

    fun isValid(x: Int, y: Int): Boolean {
        return x in 0 until numRows && y in 0 until numCols && map[x][y] != '.'
    }

    fun dfs(x: Int, y: Int, height: Int): Int {
        if (!isValid(x, y) || map[x][y].digitToInt() != height) return 0
        if (height == 9) return 1

        var score = 0
        val nextHeight = height + 1
        for ((dx, dy) in directions) {
            val nx = x + dx
            val ny = y + dy
            score += dfs(nx, ny, nextHeight)
        }
        return score
    }

    var totalScore = 0

    for (x in 0 until numRows) {
        for (y in 0 until numCols) {
            if (map[x][y] == '0') {
                totalScore += dfs(x, y, 0)
            }
        }
    }

    return totalScore
}

fun main() {
    val fileName = "10b.txt"
    val map = File(fileName).readLines()

    val totalScore = calculateTrailheadScores(map)
    println(totalScore)
}
