import java.io.File
import kotlin.time.times

fun main() {
    val input = File("9b.txt").readText().trim()

    val output = generateDiskMap(input)

    println(output)

    val movedOutput = move(output)

    println(movedOutput)

    println(count(movedOutput))
}

fun count(movedOutput: String): Long {
    var count = 0L
    for (i in movedOutput.indices) {
        if (movedOutput[i] == '.') {
            continue
        }
        count += i * (movedOutput[i] - '0')
    }
    return count
}

fun generateDiskMap(input: String): String {
    val result = StringBuilder()
    var fileId = 0
    var i = 0

    while (i < input.length) {
        val fileLength = input[i].digitToInt()
        val freeSpaceLength = if (i + 1 < input.length) input[i + 1].digitToInt() else 0

        result.append(String(CharArray(fileLength) { '0' + fileId }))
        fileId++

        result.append(String(CharArray(freeSpaceLength) { '.' }))

        i += 2
    }

    return result.toString()
}

fun move(output: String): String {
    val result = mutableListOf<Char>()
    for (i in output) {
        result.add(i)
    }

    var currentFree = 0
    while (currentFree < result.size && result[currentFree] != '.') {
        currentFree++
    }

    var currentFile = result.size - 1

    while (currentFree < currentFile) {
        if (result[currentFile] != '.') {
            result[currentFree] = result[currentFile]
            result[currentFile] = '.'
            currentFree++
        }

        while (currentFree < result.size && result[currentFree] != '.') {
            currentFree++
        }

        while (currentFile >= 0 && result[currentFile] == '.') {
            currentFile--
        }
    }

    return result.joinToString("")
}

