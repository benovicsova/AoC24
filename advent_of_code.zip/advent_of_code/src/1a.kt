import java.io.File

fun calculateTotalDistance(leftList: List<Int>, rightList: List<Int>): Long {
    val sortedLeft = leftList.sorted()
    val sortedRight = rightList.sorted()
    var totalDistance: Long = 0
    for (i in sortedLeft.indices) {
        totalDistance += Math.abs(sortedLeft[i] - sortedRight[i])
    }
    return totalDistance
}

fun main() {
    val filePath = "1b.txt"

    try {
        val leftList = mutableListOf<Int>()
        val rightList = mutableListOf<Int>()

        File(filePath).forEachLine { line ->
            val parts = line.trim().split("\\s+".toRegex())
            if (parts.size == 2) {
                leftList.add(parts[0].toInt())
                rightList.add(parts[1].toInt())
            }
        }
        val result = calculateTotalDistance(leftList, rightList)
        println(result)

    } catch (e: Exception) {
        println(e.message)
    }
}
