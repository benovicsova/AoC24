import java.io.File

fun evolveStones(initialStones: List<Long>, blinks: Int): Int {
    var stones = initialStones.toMutableList()

    repeat(blinks) {
        val newStones = mutableListOf<Long>()

        for (stone in stones) {
            when {
                stone == 0L -> {
                    newStones.add(1)
                }
                stone.toString().length % 2 == 0 -> {
                    val numStr = stone.toString()
                    val mid = numStr.length / 2
                    val left = numStr.substring(0, mid).toLong()
                    val right = numStr.substring(mid).toLong()
                    newStones.add(left)
                    newStones.add(right)
                }
                else -> {
                    newStones.add(stone * 2024)
                }
            }
        }

        stones = newStones
    }

    return stones.size
}

fun main() {
    val initialStones = File("11a.txt").readText().trim()
        .split(" ")
        .map { it.toLong() }

    val blinks = 25

    val totalStones = evolveStones(initialStones, blinks)
    println(totalStones)
}
