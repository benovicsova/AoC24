import java.io.File
import kotlin.math.absoluteValue

fun main() {
    val map = mutableListOf<MutableList<Char>>()

    File("8b.txt").forEachLine { line ->
        map.add(line.toMutableList())
    }

    val antennas = mutableListOf<Triple<Int, Int, Char>>()

    for (y in map.indices) {
        for (x in map[y].indices) {
            val char = map[y][x]
            if (char.isLetterOrDigit()) {
                antennas.add(Triple(x, y, char))
            }
        }
    }

    val antinodeLocations = mutableSetOf<Pair<Int, Int>>()

    for (i in antennas.indices) {
        for (j in antennas.indices) {
            if (i == j) continue

            val (x1, y1, freq1) = antennas[i]
            val (x2, y2, freq2) = antennas[j]

            if (freq1 == freq2) {
                val dx = x2 - x1
                val dy = y2 - y1

                var currentX = x1
                var currentY = y1

                while (isInBounds2(Pair(currentX-dx, currentY-dy), map)) {
                    antinodeLocations.add(Pair(currentX-dx, currentY-dy))
                    currentX-=dx
                    currentY-=dy
                }

                currentX = x2
                currentY = y2

                while (isInBounds2(Pair(currentX+dx, currentY+dy), map)) {
                    antinodeLocations.add(Pair(currentX+dx, currentY+dy))
                    currentX+=dx
                    currentY+=dy
                }

            }
        }
    }

    antennas.forEach { (x, y, _) ->
        antinodeLocations.add(Pair(x, y))
    }

    println(antinodeLocations.size)
}

fun isInBounds2(location: Pair<Int, Int>, map: List<List<Char>>): Boolean {
    val (x, y) = location
    return y in map.indices && x in map[y].indices
}
