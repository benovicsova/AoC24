import java.io.File


fun main() {
    val file = File("14b.txt")
    val robots = mutableListOf<Robot>()

    file.forEachLine { line ->
        val regex = """p=(-?\d+),(-?\d+) v=(-?\d+),(-?\d+)""".toRegex()
        val matchResult = regex.matchEntire(line.trim())
        matchResult?.let {
            val (p_x, p_y, v_x, v_y) = it.destructured
            robots.add(Robot(p_x.toInt(), p_y.toInt(), v_x.toInt(), v_y.toInt()))
        }
    }

    val width = 101
    val height = 103

    var seconds = 3542

    val updatedRobots = robots.map { robot ->
        var newX = (robot.p_x + (robot.v_x*3542)) % width
        if (newX < 0) {
            newX += width
        }
        var newY = (robot.p_y + (robot.v_y*3542)) % height
        if (newY < 0) {
            newY += height
        }
        Robot(newX, newY, robot.v_x, robot.v_y)
    }

    robots.clear()
    robots.addAll(updatedRobots)

    while (!countRobotsInQuadrants2(robots, width, height)) {
        val updatedRobots = robots.map { robot ->
            var newX = (robot.p_x + (robot.v_x)) % width
            if (newX < 0) {
                newX += width
            }
            var newY = (robot.p_y + (robot.v_y)) % height
            if (newY < 0) {
                newY += height
            }
            Robot(newX, newY, robot.v_x, robot.v_y)
        }

        robots.clear()
        robots.addAll(updatedRobots)
        seconds++
    }

    println(seconds)
}


fun countRobotsInQuadrants2(robots: List<Robot>, width: Int, height: Int): Boolean {
    var unique = HashSet<Pair<Int, Int>>()
    for (robot in robots) {
        unique.add(Pair(robot.p_x, robot.p_y))
    }
    println(unique)
    return unique.size == robots.size

}


