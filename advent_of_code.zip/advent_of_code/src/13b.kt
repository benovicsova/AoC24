import java.io.File

data class MachineConfig2(
    val aX: Long, val aY: Long, val bX: Long, val bY: Long, val prizeX: Long, val prizeY: Long
)

fun pressButtons(aX: Long, aY: Long, bX: Long, bY: Long, prizeX: Long, prizeY: Long): Long {
    val det = aX * bY - aY * bX

    if (det == 0L) {
        return 0L
    }

    val a = (prizeX * bY - prizeY * bX) / det
    val b = (aX * prizeY - aY * prizeX) / det

    if (aX * a + bX * b == prizeX && aY * a + bY * b == prizeY) {
        return a * 3 + b
    }
    return 0L
}

fun findMinTokens2(machine: MachineConfig2): Long {
    val (aX, aY, bX, bY, prizeX, prizeY) = machine
    return pressButtons(aX, aY, bX, bY, prizeX, prizeY)
}

fun main() {
    val inputFile = File("13b.txt")
    val lines = inputFile.readLines()

    val machines = mutableListOf<MachineConfig2>()
    var currentMachine = mutableListOf<String>()

    for (line in lines) {
        if (line.trim().isEmpty()) {
            if (currentMachine.isNotEmpty()) {
                val A = currentMachine[0].split(": ")[1].split(", ")
                val B = currentMachine[1].split(": ")[1].split(", ")
                val prize = currentMachine[2].split(": ")[1].split(", ")

                val aX = A[0].substring(2).toLong()
                val aY = A[1].substring(2).toLong()
                val bX = B[0].substring(2).toLong()
                val bY = B[1].substring(2).toLong()
                val prizeX = prize[0].substring(2).toLong() + 10000000000000L
                val prizeY = prize[1].substring(2).toLong() + 10000000000000L

                machines.add(MachineConfig2(aX, aY, bX, bY, prizeX, prizeY))
                currentMachine.clear()
            }
        } else {
            currentMachine.add(line.trim())
        }
    }

    if (currentMachine.isNotEmpty()) {
        val A = currentMachine[0].split(": ")[1].split(", ")
        val B = currentMachine[1].split(": ")[1].split(", ")
        val prize = currentMachine[2].split(": ")[1].split(", ")

        val aX = A[0].substring(2).toLong()
        val aY = A[1].substring(2).toLong()
        val bX = B[0].substring(2).toLong()
        val bY = B[1].substring(2).toLong()
        val prizeX = prize[0].substring(2).toLong() + 10000000000000L
        val prizeY = prize[1].substring(2).toLong() + 10000000000000L

        machines.add(MachineConfig2(aX, aY, bX, bY, prizeX, prizeY))
    }

    var totalTokens = 0L

    for (machine in machines) {
        val minTokens = findMinTokens2(machine)
        totalTokens += minTokens
    }

    println(totalTokens)
}
