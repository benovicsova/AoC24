import java.io.File

fun main() {
    val filePath = "3a.txt"
    val input = File(filePath).readText()

    val regex = "mul\\((\\d{1,3}),\\s*(\\d{1,3})\\)".toRegex()
    var sum = 0

    regex.findAll(input).forEach {
        val x = it.groupValues[1].toInt()
        val y = it.groupValues[2].toInt()
        sum += x * y
    }

    println(sum)
}
