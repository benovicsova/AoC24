import java.io.File

fun main() {
    val map = mutableListOf<MutableList<Char>>()

    File("8b.txt").forEachLine { line ->
        map.add(line.toMutableList())
    }

    val antennas = mutableListOf<Triple<Int, Int, Char>>()

    for (y in map.indices) {
        for (x in map[y].indices) {
            val char = map[y][x]
            if (char.isLetterOrDigit()) {
                antennas.add(Triple(x, y, char))
            }
        }
    }

    val antinodeLocations = mutableSetOf<Pair<Int, Int>>()

    // Výpočet uzlov
    for (i in antennas.indices) {
        for (j in antennas.indices) {
            if (i == j) continue

            val (x1, y1, freq1) = antennas[i]
            val (x2, y2, freq2) = antennas[j]

            if (freq1 == freq2) {

                val antinode1 = Pair(x1-x2+x1, y1-y2+y1)
                val antinode2 = Pair(x2-x1+x2, y2-y1+y2)

                if (isInBounds(antinode1, map)) {
                    antinodeLocations.add(antinode1)
                }
                if (isInBounds(antinode2, map)) {
                    antinodeLocations.add(antinode2)
                }
            }
        }
    }

    println(antinodeLocations.size)
}

fun isInBounds(location: Pair<Int, Int>, map: List<List<Char>>): Boolean {
    val (x, y) = location
    return y in map.indices && x in map[y].indices
}
