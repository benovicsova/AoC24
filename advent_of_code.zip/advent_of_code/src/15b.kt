import java.io.File

fun main() {
    val inputFile = File("15b.txt")
    val lines = inputFile.readLines()

    val map = mutableListOf<CharArray>()
    val instructions = mutableListOf<Char>()

    var isInstructionPart = false


    for (line in lines) {
        if (line.isBlank()) {
            isInstructionPart = true
        } else {
            if (isInstructionPart) {
                instructions.addAll(line.trim().toList())
            } else {
                map.add(line.trim().toCharArray())
            }
        }
    }

    val mapArray2 = map.toTypedArray()

    val mapArray = mapArray2.map { row ->
        row.map { char ->
            when (char) {
                '#' -> "##"
                'O' -> "[]"
                '.' -> ".."
                '@' -> "@."
                else -> char.toString()
            }
        }.joinToString("").toCharArray()
    }.toTypedArray()


    var robot =  Pair(0, 0)

    for (y in mapArray.indices) {
        for (x in mapArray[y].indices) {
            if (mapArray[y][x] == '@') {
                robot =  Pair(y, x)
            }
        }
    }

    val newMap = spusti2(mapArray, instructions, robot)


    val red = "\u001B[31m"
    val reset = "\u001B[0m"

    for (row in newMap) {
        for (cell in row) {
            // Ak je znak '@', vypíš ho červený
            if (cell == '@') {
                print("${red}$cell${reset}")
            } else {
                print(cell)
            }
        }
        println()
    }

    println(sumBox2(newMap))

}

fun sumBox2(newMap: Array<CharArray>): Int {
    var sum = 0
    for (y in newMap.indices) {
        for (x in newMap[y].indices) {
            if (newMap[y][x] == '[') {
                sum+= 100*y + x
            }
        }
    }
    return sum
}

fun spusti2(mapArray_: Array<CharArray>, instructions: MutableList<Char>, robot: Pair<Int, Int>): Array<CharArray> {
    var mapArray = mapArray_
    var current = robot
    for (instruction in instructions) {

        extracted(mapArray, instruction)

        if (instruction == '^') {
            if (isInRange2(current.first - 1, current.second, mapArray)) {
                //hore je volno
                if (mapArray[current.first - 1][current.second] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first - 1][current.second] = '@'
                    current = Pair(current.first - 1, current.second)

                    //hore je krabica

                } else if (mapArray[current.first - 1][current.second] == '[') {
                    var pocetBoxov = 1
                    while (mapArray[current.first - pocetBoxov][current.second] == '[') {
                        pocetBoxov++
                    }
                    if (pocetBoxov>3){
                        continue
                    } else if (mapArray[current.first - pocetBoxov][current.second] == '#') {
                        continue
                    } else if (mapArray[current.first - pocetBoxov][current.second] == '.') {
                        if (mapArray[current.first - pocetBoxov][current.second + 1] == '.') {
                            while (pocetBoxov != 1) {
                                mapArray[current.first - pocetBoxov][current.second] = '['
                                mapArray[current.first - pocetBoxov][current.second + 1] = ']'
                                pocetBoxov--
                            }
                            mapArray[current.first][current.second] = '.'
                            mapArray[current.first - 1][current.second + 1] = '.'
                            mapArray[current.first - 1][current.second] = '@'
                            current = Pair(current.first - 1, current.second)
                        } else {
                            continue
                        }
                    }

                } else if (mapArray[current.first - 1][current.second] == ']') {
                    var pocetBoxov = 1
                    while (mapArray[current.first - pocetBoxov][current.second] == ']') {
                        pocetBoxov++
                    }
                    if (pocetBoxov>3){
                        continue
                    } else if (mapArray[current.first - pocetBoxov][current.second] == '#') {
                        continue
                    } else if (mapArray[current.first - pocetBoxov][current.second] == '.') {
                        if (mapArray[current.first - pocetBoxov][current.second - 1] == '.') {
                            while (pocetBoxov != 1) {
                                mapArray[current.first - pocetBoxov][current.second] = ']'
                                mapArray[current.first - pocetBoxov][current.second - 1] = '['
                                pocetBoxov--
                            }
                            mapArray[current.first][current.second] = '.'
                            mapArray[current.first - 1][current.second - 1] = '.'
                            mapArray[current.first - 1][current.second] = '@'
                            current = Pair(current.first - 1, current.second)
                        } else {
                            continue
                        }
                    }
                }
            }
        } else if (instruction == 'v') {
                if (isInRange2(current.first+1, current.second, mapArray)) {
                    if (mapArray[current.first+1][current.second] == '.') {
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first+1][current.second] = '@'
                        current = Pair(current.first+1, current.second)

                } else if (mapArray[current.first+1][current.second] == '[') {
                    var pocetBoxov = 1
                    while (mapArray[current.first+pocetBoxov][current.second] == '['){
                        pocetBoxov++
                    }
                    if (pocetBoxov>3){
                        continue
                    } else if (mapArray[current.first+pocetBoxov][current.second] == '#'){
                        continue
                    } else if (mapArray[current.first+pocetBoxov][current.second] == '.') {
                        if (mapArray[current.first + pocetBoxov][current.second + 1] == '.') {
                            while (pocetBoxov != 1) {
                                mapArray[current.first + pocetBoxov][current.second] = '['
                                mapArray[current.first + pocetBoxov][current.second + 1] = ']'
                                pocetBoxov--
                            }
                            mapArray[current.first][current.second] = '.'
                            mapArray[current.first + 1][current.second + 1] = '.'
                            mapArray[current.first + 1][current.second] = '@'
                            current = Pair(current.first + 1, current.second)
                        } else {
                            continue
                        }
                    }

                }  else if (mapArray[current.first+1][current.second] == ']') {
                    var pocetBoxov = 1
                    while (mapArray[current.first+pocetBoxov][current.second] == ']'){
                        pocetBoxov++
                    }
                    if (pocetBoxov>3){
                        continue
                    } else if (mapArray[current.first+pocetBoxov][current.second] == '#'){
                        continue
                    } else if (mapArray[current.first+pocetBoxov][current.second] == '.') {
                        if (mapArray[current.first + pocetBoxov][current.second - 1] == '.') {
                            while (pocetBoxov != 1) {
                                mapArray[current.first + pocetBoxov][current.second] = ']'
                                mapArray[current.first + pocetBoxov][current.second - 1] = '['
                                pocetBoxov--
                            }
                            mapArray[current.first][current.second] = '.'
                            mapArray[current.first + 1][current.second - 1] = '.'
                            mapArray[current.first + 1][current.second] = '@'
                            current = Pair(current.first + 1, current.second)
                        } else {
                            continue
                        }
                    }
                }
            }

        } else if (instruction == '>'){
            if (isInRange2(current.first, current.second+1, mapArray)) {
                if (mapArray[current.first][current.second+1] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first][current.second+1] = '@'
                    current = Pair(current.first, current.second+1)

                } else if (mapArray[current.first][current.second+1] == '[') {
                    var pocetBoxov = 1
                    while (mapArray[current.first][current.second+pocetBoxov] == ']' || mapArray[current.first][current.second+pocetBoxov] == '['){
                        pocetBoxov++
                    }
                    if (pocetBoxov>5){
                        continue
                    } else  if (mapArray[current.first][current.second+pocetBoxov] == '#'){
                        continue
                    } else if (mapArray[current.first][current.second+pocetBoxov] == '.'){
                        while (pocetBoxov!=1){
                            if (pocetBoxov%2==1) {
                                mapArray[current.first][current.second + pocetBoxov] = ']'
                            } else {
                                mapArray[current.first][current.second + pocetBoxov] = '['
                            }
                            pocetBoxov--
                        }
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first][current.second+1] = '@'
                        current = Pair(current.first, current.second+1)
                    }
                }
            }
        } else if (instruction == '<'){
            /*println("moje suradnice su $current")
            println("rozmery pola su ${mapArray.size} a ${mapArray[0].size} ")*/
            if (isInRange2(current.first, current.second-1, mapArray)) {
                if (mapArray[current.first][current.second-1] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first][current.second-1] = '@'
                    current = Pair(current.first, current.second-1)

                } else if (mapArray[current.first][current.second-1] == ']') {
                    var pocetBoxov = 1
                    while (mapArray[current.first][current.second-pocetBoxov] == ']' || mapArray[current.first][current.second-pocetBoxov] == '['){
                        pocetBoxov++
                    }
                    if (pocetBoxov>5){
                        continue
                    } else if (mapArray[current.first][current.second-pocetBoxov] == '#'){
                        continue
                    } else if (mapArray[current.first][current.second-pocetBoxov] == '.'){
                        while (pocetBoxov!=1){
                            if (pocetBoxov%2==1) {
                                mapArray[current.first][current.second - pocetBoxov] = '['
                            } else {
                                mapArray[current.first][current.second - pocetBoxov] = ']'
                            }
                            pocetBoxov--
                        }
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first][current.second-1] = '@'
                        current = Pair(current.first, current.second-1)
                    }
                }
            }
        } else {
            continue
        }
    }

    return mapArray
}

private fun extracted(mapArray: Array<CharArray>, instruction: Char) {
    val red = "\u001B[31m"
    val reset = "\u001B[0m"

    for (row in mapArray) {
        for (cell in row) {
            if (cell == '@') {
                print("${red}$cell${reset}")
            } else {
                print(cell)
            }
        }
        println()
    }
    println("instrukcia je $instruction")
}

fun isInRange2(first: Int, second: Int, mapArray: Array<CharArray>): Boolean {
    return first>0 && second>0 && first<mapArray.size-1 && second< mapArray[0].size-1
}

