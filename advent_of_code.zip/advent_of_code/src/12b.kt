import java.io.File

fun calculateFencingCost2(map: List<String>): Int {
    val rows = map.size
    val cols = map[0].length
    val visited = Array(rows) { BooleanArray(cols) }
    var totalCost = 0

    val directions = listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))

    fun isValid(x: Int, y: Int) = x in 0 until rows && y in 0 until cols

    fun floodFillWithEdges(x: Int, y: Int, plant: Char): Pair<Int, List<Pair<Pair<Int, Int>, Pair<Int, Int>>>> {
        var area = 0
        val edges = mutableListOf<Pair<Pair<Int, Int>, Pair<Int, Int>>>()
        val queue = ArrayDeque<Pair<Int, Int>>()
        queue.add(Pair(x, y))
        visited[x][y] = true

        while (queue.isNotEmpty()) {
            val (cx, cy) = queue.removeFirst()
            area++

            for ((dx, dy) in directions) {
                val nx = cx + dx
                val ny = cy + dy

                if (!isValid(nx, ny) || map[nx][ny] != plant) {
                    // Record the edge as a boundary
                    val edge = if (dx == 0) {
                        Pair(Pair(cx, cy), Pair(cx, cy + dy))
                    } else {
                        Pair(Pair(cx, cy), Pair(cx + dx, cy))
                    }
                    edges.add(edge)
                } else if (!visited[nx][ny]) {
                    visited[nx][ny] = true
                    queue.add(Pair(nx, ny))
                }
            }
        }

        return Pair(area, edges)
    }


    fun countSides(edges: List<Pair<Pair<Int, Int>, Pair<Int, Int>>>): Int {

        fun isHorizontal(edge: Pair<Pair<Int, Int>, Pair<Int, Int>>): Boolean {
            return edge.first.first == edge.second.first
        }

        fun isVertical(edge: Pair<Pair<Int, Int>, Pair<Int, Int>>): Boolean {
            return edge.first.second == edge.second.second
        }

        val horizontalEdges = edges.filter { isHorizontal(it) }.toMutableList()
        val verticalEdges = edges.filter { isVertical(it) }.toMutableList()

        var linesCount = 0

        while (horizontalEdges.isNotEmpty()) {
            var first = horizontalEdges.first()
            var current = first

            var x1 = current.first.first
            var y1 = current.first.second
            var x2 = current.second.first
            var y2 = current.second.second

            while (horizontalEdges.contains(Pair(Pair(x1 + 1, y1), Pair(x2 + 1, y2)))) {
                horizontalEdges.remove(Pair(Pair(x1+1, y1), Pair(x2+1, y2)))
                current = Pair(Pair(x1+1, y1), Pair(x2+1, y2))
                 x1 = current.first.first
                 y1 = current.first.second
                 x2 = current.second.first
                 y2 = current.second.second
            }

            current = first

            x1 = current.first.first
            y1 = current.first.second
            x2 = current.second.first
            y2 = current.second.second

            while (horizontalEdges.contains(Pair(Pair(x1 - 1, y1), Pair(x2 - 1, y2)))) {
                horizontalEdges.remove(Pair(Pair(x1-1, y1), Pair(x2-1, y2)))
                current = Pair(Pair(x1-1, y1), Pair(x2-1, y2))
                 x1 = current.first.first
                 y1 = current.first.second
                 x2 = current.second.first
                 y2 = current.second.second
            }

            linesCount++
            horizontalEdges.remove(first)
        }

        while (verticalEdges.isNotEmpty()) {
            var first = verticalEdges.first()
            var current = first

            var x1 = current.first.first
            var y1 = current.first.second
            var x2 = current.second.first
            var y2 = current.second.second

            while (verticalEdges.contains(Pair(Pair(x1 , y1+1), Pair(x2 , y2+1)))) {
                verticalEdges.remove(Pair(Pair(x1 , y1+1), Pair(x2 , y2+1)))
                current = Pair(Pair(x1 , y1+1), Pair(x2 , y2+1))
                x1 = current.first.first
                y1 = current.first.second
                x2 = current.second.first
                y2 = current.second.second
            }

            current = first

            x1 = current.first.first
            y1 = current.first.second
            x2 = current.second.first
            y2 = current.second.second

            while (verticalEdges.contains(Pair(Pair(x1 , y1-1), Pair(x2 , y2-1)))) {
                verticalEdges.remove(Pair(Pair(x1 , y1-1), Pair(x2 , y2-1)))
                current = Pair(Pair(x1 , y1-1), Pair(x2 , y2-1))
                x1 = current.first.first
                y1 = current.first.second
                x2 = current.second.first
                y2 = current.second.second
            }

            linesCount++
            verticalEdges.remove(first)
        }

        println(linesCount)
        return linesCount
    }




    for (x in 0 until rows) {
        for (y in 0 until cols) {
            if (!visited[x][y]) {
                val plant = map[x][y]
                val (area, edges) = floodFillWithEdges(x, y, plant)
                val sides = countSides(edges)
                totalCost += area * sides
            }
        }
    }

    return totalCost
}

private operator fun <A : Comparable<A>, B : Comparable<B>> Pair<A, B>.compareTo(second: Pair<A, B>): Int {
    val firstComparison = this.first.compareTo(second.first)
    return if (firstComparison != 0) {
        firstComparison
    } else {
        this.second.compareTo(second.second)
    }
}


fun main() {
    val filePath = "12b.txt"
    val map = File(filePath).readLines()

    val totalCost = calculateFencingCost2(map)
    println(totalCost)
}
