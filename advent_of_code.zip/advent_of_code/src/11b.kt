import java.io.File

fun evolveStonesOptimized2(initialStones: List<Long>, blinks: Int): Long {
    var frequencyMap = initialStones.groupingBy { it }.eachCount().mapValues { it.value.toLong() }.toMutableMap()

    repeat(blinks) {
        val newFrequencyMap = mutableMapOf<Long, Long>()

        for ((stone, count) in frequencyMap) {
            when {
                stone == 0L -> {
                    newFrequencyMap[1] = (newFrequencyMap[1] ?: 0) + count
                }
                stone.toString().length % 2 == 0 -> {
                    val numStr = stone.toString()
                    val mid = numStr.length / 2
                    val left = numStr.substring(0, mid).toLong()
                    val right = numStr.substring(mid).toLong()

                    newFrequencyMap[left] = (newFrequencyMap[left] ?: 0) + count
                    newFrequencyMap[right] = (newFrequencyMap[right] ?: 0) + count
                }
                else -> {
                    val newStone = stone * 2024
                    newFrequencyMap[newStone] = (newFrequencyMap[newStone] ?: 0) + count
                }
            }
        }

        frequencyMap = newFrequencyMap
    }

    return frequencyMap.values.sum()
}

fun main() {
    val filePath = "11b.txt"
    val initialStones = File(filePath).readText().trim()
        .split(" ")
        .map { it.toLong() }

    val blinks = 75

    val totalStones = evolveStonesOptimized2(initialStones, blinks)
    println(totalStones)
}
