import java.io.File

fun countXmasOccurrences2(grid: List<String>): Int {
    val rows = grid.size
    val cols = grid[0].length
    var count = 0

    fun isMatch(r: Int, c: Int): Boolean {
        if (r-1 < 0 || c-1 < 0 || r+1 >= rows || c+1 >= cols) { return false}
        val directions = listOf(
            Pair(1, 1),
            Pair(1, -1),
            Pair(-1, -1),
            Pair(-1, 1)
        )
        for ((dr, dc) in directions) {
            if (grid[r+dr][c+dc]!='S' && grid[r+dr][c+dc]!='M'){
                return false
            }
            if (grid[r+dr][c+dc]=='S'){
                if (grid[r-dr][c-dc]!='M'){
                    return false;
                }
            } else if (grid[r+dr][c+dc]=='M'){
                if (grid[r-dr][c-dc]!='S'){
                    return false;
                }
            }
        }
        return true
    }

    for (r in 0 until rows) {
        for (c in 0 until cols) {
            if (grid[r][c]=='A') {
                if (isMatch(r, c)) {
                    count++
                }
            }
        }
    }
    return count
}

fun main() {
    val filePath = "4b.txt"
    val grid = File(filePath).readLines()
    println(countXmasOccurrences2(grid))
}
