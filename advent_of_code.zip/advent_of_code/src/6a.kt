import java.io.File

fun main() {
    val input = File("6b.txt").readText()

    val lines = input.split("\n")
    val grid = Array(lines.size) { CharArray(lines[0].length) }

    var currentPosition = Pair(0,0)

    for (i in lines.indices) {
        for (j in lines[i].indices) {
            if (lines[i][j] == '^'){
                currentPosition = Pair(i, j)
                grid[i][j] = 'X'
            } else {
                grid[i][j] = lines[i][j]
            }
        }
    }

    print(CountPositions(grid,currentPosition))
}

fun CountPositions(grid: Array<CharArray>, currentPosition_: Pair<Int,Int>): Int {
    var count = 1
    var direction = Pair(-1, 0)
    var currentPosition = currentPosition_
    while (currentPosition.first+direction.first >= 0 &&
        currentPosition.first+direction.first < grid.size &&
        currentPosition.second+direction.second >= 0 &&
        currentPosition.second+direction.second < grid.size){
        if (grid[currentPosition.first+direction.first][currentPosition.second+direction.second] == '#'){
            if (direction == Pair(-1, 0)){ //hore
                direction = Pair(0,1)
            } else if (direction == Pair(1, 0)){ //dole
                direction = Pair(0,-1)
            } else if (direction == Pair(0, -1)){ //vpravo
                direction = Pair(-1, 0)
            } else { //vpravo
                direction = Pair(1, 0)
            }
        } else if (grid[currentPosition.first+direction.first][currentPosition.second+direction.second] == 'X'){
            currentPosition = Pair(currentPosition.first + direction.first,currentPosition.second + direction.second)
        } else {
            currentPosition = Pair(currentPosition.first + direction.first,currentPosition.second + direction.second)
            grid[currentPosition.first][currentPosition.second] = 'X'
            count++
        }
    }
    for (row in grid) {
        println(row.joinToString(""))
    }
    return count
}
