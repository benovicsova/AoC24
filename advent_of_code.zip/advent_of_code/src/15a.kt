import java.io.File

fun main() {
    val inputFile = File("15c.txt")
    val lines = inputFile.readLines()

    val map = mutableListOf<CharArray>()
    val instructions = mutableListOf<Char>()

    var isInstructionPart = false


    for (line in lines) {
        if (line.isBlank()) {
            isInstructionPart = true
        } else {
            if (isInstructionPart) {
                instructions.addAll(line.trim().toList())
            } else {
                map.add(line.trim().toCharArray())
            }
        }
    }

    val mapArray = map.toTypedArray()

    var robot =  Pair(0, 0)

    for (y in mapArray.indices) {
        for (x in mapArray[y].indices) {
            if (mapArray[y][x] == '@') {
                robot =  Pair(x, y)
            }
        }
    }

    val newMap = spusti(mapArray, instructions, robot)

    println(sumBox(newMap))

}

fun sumBox(newMap: Array<CharArray>): Int {
    var sum = 0
    for (y in newMap.indices) {
        for (x in newMap[y].indices) {
            if (newMap[y][x] == 'O') {
                sum+= 100*y + x
            }
        }
    }
    return sum
}

fun spusti(mapArray_: Array<CharArray>, instructions: MutableList<Char>, robot: Pair<Int, Int>): Array<CharArray> {
    var mapArray = mapArray_
    println(instructions)
    var current = robot
    for (instruction in instructions) {

/*        for (y in mapArray.indices) {
            for (x in mapArray[y].indices) {
                print(mapArray[y][x])
            }
            println()
        }
        println()
        println("instrukcia je $instruction")*/

        if (instruction == '^'){
            if (isInRange(current.first-1, current.second, mapArray)) {
                if (mapArray[current.first-1][current.second] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first-1][current.second] = '@'
                    current = Pair(current.first-1, current.second)
                } else if (mapArray[current.first-1][current.second] == 'O') {
                    var pocetBoxov = 1
                    while (mapArray[current.first-pocetBoxov][current.second] == 'O'){
                        pocetBoxov++
                    }
                    if (mapArray[current.first-pocetBoxov][current.second] == '#'){
                        continue
                    } else if (mapArray[current.first-pocetBoxov][current.second] == '.'){
                        while (pocetBoxov!=1){
                            mapArray[current.first-pocetBoxov][current.second] = 'O'
                            pocetBoxov--
                        }
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first-1][current.second] = '@'
                        current = Pair(current.first-1, current.second)
                    }
                }
            }
        } else if (instruction == 'v'){
            if (isInRange(current.first+1, current.second, mapArray)) {
                if (mapArray[current.first+1][current.second] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first+1][current.second] = '@'
                    current = Pair(current.first+1, current.second)
                } else if (mapArray[current.first+1][current.second] == 'O') {
                    var pocetBoxov = 1
                    while (mapArray[current.first+pocetBoxov][current.second] == 'O'){
                        pocetBoxov++
                    }
                    if (mapArray[current.first+pocetBoxov][current.second] == '#'){
                        continue
                    } else if (mapArray[current.first+pocetBoxov][current.second] == '.'){
                        while (pocetBoxov!=1){
                            mapArray[current.first+pocetBoxov][current.second] = 'O'
                            pocetBoxov--
                        }
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first+1][current.second] = '@'
                        current = Pair(current.first+1, current.second)
                    }
                }
            }
        } else if (instruction == '>'){
            if (isInRange(current.first, current.second+1, mapArray)) {
                if (mapArray[current.first][current.second+1] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first][current.second+1] = '@'
                    current = Pair(current.first, current.second+1)
                } else if (mapArray[current.first][current.second+1] == 'O') {
                    var pocetBoxov = 1
                    while (mapArray[current.first][current.second+pocetBoxov] == 'O'){
                        pocetBoxov++
                    }
                    if (mapArray[current.first][current.second+pocetBoxov] == '#'){
                        continue
                    } else if (mapArray[current.first][current.second+pocetBoxov] == '.'){
                        while (pocetBoxov!=1){
                            mapArray[current.first][current.second+pocetBoxov] = 'O'
                            pocetBoxov--
                        }
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first][current.second+1] = '@'
                        current = Pair(current.first, current.second+1)
                    }
                }
            }
        } else if (instruction == '<'){
            if (isInRange(current.first, current.second-1, mapArray)) {
                if (mapArray[current.first][current.second-1] == '.') {
                    mapArray[current.first][current.second] = '.'
                    mapArray[current.first][current.second-1] = '@'
                    current = Pair(current.first, current.second-1)
                } else if (mapArray[current.first][current.second-1] == 'O') {
                    var pocetBoxov = 1
                    while (mapArray[current.first][current.second-pocetBoxov] == 'O'){
                        pocetBoxov++
                    }
                    if (mapArray[current.first][current.second-pocetBoxov] == '#'){
                        continue
                    } else if (mapArray[current.first][current.second-pocetBoxov] == '.'){
                        while (pocetBoxov!=1){
                            mapArray[current.first][current.second-pocetBoxov] = 'O'
                            pocetBoxov--
                        }
                        mapArray[current.first][current.second] = '.'
                        mapArray[current.first][current.second-1] = '@'
                        current = Pair(current.first, current.second-1)
                    }
                }
            }
        } else {
            continue
        }


    }

    return mapArray
}

fun isInRange(first: Int, second: Int, mapArray: Array<CharArray>): Boolean {
    return first>0 && second>0 && first<mapArray.size-1 && second< mapArray[0].size-1
}
