import java.io.File
import kotlin.time.times

fun main() {
    val input = File("9b.txt").readText().trim()

    val output = generateDiskMap2(input)

    println(output)

    val movedOutput = move2(output)

    println(movedOutput)

    println(count2(movedOutput))
}

fun count2(movedOutput: String): Long {
    var count = 0L
    for (i in movedOutput.indices) {
        if (movedOutput[i] == '.') {
            continue
        }
        count += i * (movedOutput[i] - '0')
    }
    return count
}

fun generateDiskMap2(input: String): String {
    val result = StringBuilder()
    var fileId = 0
    var i = 0

    while (i < input.length) {
        val fileLength = input[i].digitToInt()
        val freeSpaceLength = if (i + 1 < input.length) input[i + 1].digitToInt() else 0

        result.append(String(CharArray(fileLength) { '0' + fileId }))
        fileId++

        result.append(String(CharArray(freeSpaceLength) { '.' }))

        i += 2
    }

    return result.toString()
}

fun move2(output: String): String {
    val result = output.toMutableList()

    var currentFile = result.size - 1

    while (currentFile >= 0) {
        val currentFileID = result[currentFile]
        var fileLength = 1

        while (currentFile - 1 >= 0 && result[currentFile - 1] == currentFileID) {
            fileLength++
            currentFile--
        }

        var currentFreeSpace = 0
        while (currentFreeSpace < result.size && result[currentFreeSpace] != '.') {
            currentFreeSpace++
        }

        while (currentFreeSpace < currentFile) {
            var freeLength = 0

            while (currentFreeSpace + freeLength < result.size && result[currentFreeSpace + freeLength] == '.') {
                freeLength++
            }

            if (freeLength >= fileLength) {
                for (i in 0 until fileLength) {
                    result[currentFreeSpace + i] = result[currentFile + i]
                    result[currentFile + i] = '.'
                }
                break
            }

            currentFreeSpace++
        }

        currentFile--

        while (currentFile >= 0 && result[currentFile] == '.') {
            currentFile--
        }

    }

    return result.joinToString("")
}
