import java.io.File

fun main() {
    val input = File("7b.txt").readLines()

    var count = 0L
    for (line in input) {
        val (testValue, numbers) = parseInput(line)
        if (canMatchTestValue(testValue, numbers)) {
            count += testValue
        }
    }

    println(count)
}

fun parseInput(line: String): Pair<Long, List<Long>> {
    val parts = line.split(": ")
    val testValue = parts[0].toLong()
    val numbers = parts[1].split(" ").map { it.toLong() }
    return Pair(testValue, numbers)
}

fun canMatchTestValue(testValue: Long, numbers: List<Long>): Boolean {
    return evaluateCombinations(numbers, testValue, 0, numbers[0])
}

fun evaluateCombinations(numbers: List<Long>, testValue: Long, index: Int, currentResult: Long): Boolean {
    if (index == numbers.lastIndex) {
        return currentResult == testValue
    }

    val nextIndex = index + 1
    val addResult = evaluateCombinations(numbers, testValue, nextIndex, currentResult + numbers[nextIndex])
    val multiplyResult = evaluateCombinations(numbers, testValue, nextIndex, currentResult * numbers[nextIndex])

    return addResult || multiplyResult
}
