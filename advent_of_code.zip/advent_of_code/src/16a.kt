import java.io.File
import java.util.PriorityQueue

data class State(val x: Int, val y: Int, val direction: Int, val score: Int) : Comparable<State> {
    override fun compareTo(other: State): Int = this.score - other.score
}

fun main() {
    val map = File("16c.txt").readLines().map { it.toCharArray() }

    val start = map.indices.flatMap { y -> map[0].indices.map { x -> Pair(x, y) } }
        .first { map[it.second][it.first] == 'S' }
    val end = map.indices.flatMap { y -> map[0].indices.map { x -> Pair(x, y) } }
        .first { map[it.second][it.first] == 'E' }

    println(search(start, end, map))
}

private fun search(
    start: Pair<Int, Int>,
    end: Pair<Int, Int>,
    map: List<CharArray>
): Int {
    val directions = listOf(Pair(1, 0), Pair(0, 1), Pair(-1, 0), Pair(0, -1))

    val queue = PriorityQueue<State>()
    val visited = mutableSetOf<Triple<Int, Int, Int>>()

    queue.add(State(start.first, start.second, 0, 0))

    while (queue.isNotEmpty()) {
        val current = queue.poll()

        if (!visited.add(Triple(current.x, current.y, current.direction))) continue

        if (current.x == end.first && current.y == end.second) {
            return current.score
        }

        val nextX = current.x + directions[current.direction].first
        val nextY = current.y + directions[current.direction].second

        if (nextX in map[0].indices && nextY in map.indices && map[nextY][nextX] != '#') {
            queue.add(State(nextX, nextY, current.direction, current.score + 1))
        }

        val rightDirection = (current.direction + 1) % 4
        queue.add(State(current.x, current.y, rightDirection, current.score + 1000))

        val leftDirection = (current.direction + 3) % 4
        queue.add(State(current.x, current.y, leftDirection, current.score + 1000))
    }
    return 0
}
