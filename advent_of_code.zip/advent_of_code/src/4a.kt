import java.io.File

fun countXmasOccurrences(grid: List<String>): Int {
    val rows = grid.size
    val cols = grid[0].length
    var count = 0

    fun isMatch(r: Int, c: Int, dr: Int, dc: Int): Boolean {
        if (r+3*dr < 0 || c+3*dc < 0 || r+3*dr >= rows || c+3*dc >= cols) { return false}
        if (grid[r+dr][c+dc]!='M'){
            return false
        }
        if (grid[r+2*dr][c+2*dc]!='A'){
            return false
        }
        if (grid[r+3*dr][c+3*dc]!='S'){
            return false
        }
        return true
    }

    for (r in 0 until rows) {
        for (c in 0 until cols) {
            if (grid[r][c]=='X') {
                val directions = listOf(
                    Pair(0, 1),
                    Pair(1, 0),
                    Pair(1, 1),
                    Pair(1, -1),
                    Pair(0, -1),
                    Pair(-1, 0),
                    Pair(-1, -1),
                    Pair(-1, 1)
                )
                for ((dr, dc) in directions) {
                    if (isMatch(r, c, dr, dc)) {
                        count++
                    }
                }
            }
        }
    }
    return count
}

fun main() {
    val filePath = "4b.txt"
    val grid = File(filePath).readLines()
    println(countXmasOccurrences(grid))
}
