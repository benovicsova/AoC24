import java.io.File

fun calculateSimilarityScore(leftList: List<Int>, rightList: List<Int>): Long {
    var totalScore: Long = 0
    for (leftValue in leftList) {
        val occurrences = rightList.count { it == leftValue }
        totalScore += leftValue * occurrences
    }
    return totalScore
}

fun main() {
    val filePath = "1b.txt"

    try {
        val leftList = mutableListOf<Int>()
        val rightList = mutableListOf<Int>()

        File(filePath).forEachLine { line ->
            val parts = line.trim().split("\\s+".toRegex())
            if (parts.size == 2) {
                leftList.add(parts[0].toInt())
                rightList.add(parts[1].toInt())
            }
        }

        val result = calculateSimilarityScore(leftList, rightList)
        println(result)
    } catch (e: Exception) {
        println(e.message)
    }
}
