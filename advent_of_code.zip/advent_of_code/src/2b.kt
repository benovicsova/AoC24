import java.io.File

fun isReportSafeTrimmed(report: List<Int>): Boolean {
    var isIncreasing = true
    var isDecreasing = true

    for (i in 1 until report.size) {
        val diff = report[i] - report[i - 1]

        if (diff !in 1..3 && diff !in -3..-1) {
            return false
        }

        if (diff < 0) {
            isIncreasing = false
        } else if (diff > 0) {
            isDecreasing = false
        }
    }

    if (isIncreasing || isDecreasing){
        println(report)
    }
    return isIncreasing || isDecreasing
}

fun isReportSafeB(report: List<Int>): Boolean {
    for (i in report.indices) {
        val modifiedReport = report.filterIndexed { index, _ -> index != i }
        if (isReportSafe(modifiedReport)) {
            return true
        }
    }
    return false
}



fun main() {
    val filePath = "2a.txt"

    try {
        var safeReportsCount = 0

        File(filePath).forEachLine { line ->
            val report = line.trim().split("\\s+".toRegex()).map { it.toInt() }
            if (isReportSafeB(report)) {
                safeReportsCount++
            }
        }

        println(safeReportsCount)
    } catch (e: Exception) {
        println(e.message)
    }
}
