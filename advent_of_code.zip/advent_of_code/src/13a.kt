import java.io.File

data class MachineConfig(
    val A_x: Int, val A_y: Int, val B_x: Int, val B_y: Int, val prize_x: Int, val prize_y: Int
)

fun findMinTokens(machine: MachineConfig): Int? {
    val (A_x, A_y, B_x, B_y, prize_x, prize_y) = machine

    var minCost: Int? = null

    for (A_count in 0..100) {
        for (B_count in 0..100) {
            val currentX = A_count * A_x + B_count * B_x
            val currentY = A_count * A_y + B_count * B_y

            if (currentX == prize_x && currentY == prize_y) {
                val cost = A_count * 3 + B_count * 1
                if (minCost == null || cost < minCost) {
                    minCost = cost
                }
            }
        }
    }

    return minCost
}

fun main() {
    val inputFile = File("13b.txt")
    val lines = inputFile.readLines()

    val machines = mutableListOf<MachineConfig>()
    var currentMachine = mutableListOf<String>()

    for (line in lines) {
        if (line.trim().isEmpty()) {
            if (currentMachine.isNotEmpty()) {
                val A = currentMachine[0].split(": ")[1].split(", ")
                val B = currentMachine[1].split(": ")[1].split(", ")
                val prize = currentMachine[2].split(": ")[1].split(", ")

                val A_x = A[0].substring(2).toInt()
                val A_y = A[1].substring(2).toInt()
                val B_x = B[0].substring(2).toInt()
                val B_y = B[1].substring(2).toInt()
                val prize_x = prize[0].substring(2).toInt()
                val prize_y = prize[1].substring(2).toInt()

                machines.add(MachineConfig(A_x, A_y, B_x, B_y, prize_x, prize_y))
                currentMachine.clear()
            }
        } else {
            currentMachine.add(line.trim())
        }
    }
    var totalTokens = 0

    for (machine in machines) {
        val minTokens = findMinTokens(machine)
        if (minTokens != null) {
            totalTokens += minTokens
        }
    }
    println(totalTokens)
}
